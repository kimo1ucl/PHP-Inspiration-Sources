# PHP-Inspiration-Sources
From searches on the internet for learning examples of MVC with database activity. Could be used as inspiration for some kind of simple architecture without the burden of a mighty framework, (or perhabs in reduced amounts?)
